#!/bin/bash

echo "[x17-女娲] Removing .pytest_cache"
rm -rf .pytest_cache
echo "[x17-女娲] Done."