#!/bin/bash

echo "[x17-女娲] Installing Python dependencies (requirements.dev.txt)"
pip install -r requirements.dev.txt
echo "[x17-女娲] Done."